import React, { useEffect, useMemo, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, Pressable, FlatList, Alert, StatusBar, Platform, StyleSheet } from 'react-native';
import { computeKilometers, sumKilometers } from './src/logic';
import { loadSettings, saveSettings, loadEntries, saveEntries } from './src/storage';

const C = { bg:'#0B0F13', card:'#131A21', accent:'#4F46E5', text:'#E5E7EB', muted:'#9CA3AF', border:'#1F2937', good:'#10B981', danger:'#EF4444' };

export default function App(){
  const [tab,setTab]=useState('home');
  const [settings,setSettings]=useState({ pricePerLitre:'', mileageKmPerLitre:'' });
  const [amount,setAmount]=useState('');
  const [entries,setEntries]=useState([]);
  const [ready,setReady]=useState(false);

  useEffect(()=>{ (async()=>{ setSettings(await loadSettings()); setEntries(await loadEntries()); setReady(true); })(); },[]);

  const totalKm = useMemo(()=>sumKilometers(entries), [entries]);
  const computedKm = useMemo(()=>computeKilometers(amount, settings.pricePerLitre, settings.mileageKmPerLitre), [amount, settings]);

  const onSave = async()=>{
    const price=parseFloat(settings.pricePerLitre), kmpl=parseFloat(settings.mileageKmPerLitre);
    if(!isFinite(price)||price<=0||!isFinite(kmpl)||kmpl<=0){ Alert.alert('Invalid','Enter valid numbers for petrol price and mileage.'); return; }
    const next={ pricePerLitre:String(price), mileageKmPerLitre:String(kmpl) }; await saveSettings(next); setSettings(next); Alert.alert('Saved','Settings updated.');
  };

  const onAdd = async()=>{
    const km=computedKm, amt=parseFloat(amount);
    if(!km||!amt){ Alert.alert('Missing','Enter amount and valid settings.'); return; }
    const next=[{ id:Date.now().toString(), amount:amt, km, at:new Date().toISOString() }, ...entries]; setEntries(next); await saveEntries(next); setAmount(''); setTab('home');
  };

  const onClear = async()=>{ Alert.alert('Reset?','Delete all entries (settings kept).',[{text:'Cancel',style:'cancel'},{text:'Delete',style:'destructive',onPress: async()=>{ setEntries([]); await saveEntries([]); }}]); };
  const onDelete = async(id)=>{ const next=entries.filter(e=>e.id!==id); setEntries(next); await saveEntries(next); };

  if(!ready) return <View style={{flex:1,backgroundColor:C.bg}}/>;

  return (
    <SafeAreaView style={[styles.safe,{ paddingTop: Platform.OS==='android' ? (StatusBar.currentHeight||0) : 0 }]}>
      <StatusBar barStyle="light-content"/>
      <View style={styles.wrap}>
        <Text style={styles.title}>Bike Mileage</Text>
        <Text style={styles.subtitle}>Enter amount paid. We calculate expected kilometers and add to total.</Text>

        <View style={styles.seg}>
          {['home','add','settings'].map(k=> (
            <Pressable key={k} onPress={()=>setTab(k)} style={[styles.segBtn, tab===k && styles.segBtnActive]}>
              <Text style={[styles.segText, tab===k && styles.segTextActive]}>{k==='home'?'Home':k==='add'?'Add Refill':'Settings'}</Text>
            </Pressable>
          ))}
        </View>

        {tab==='home' && (
          <View style={{gap:16, marginTop:16}}>
            <View style={styles.card}>
              <Text style={styles.mutedSmall}>Total Expected Range</Text>
              <Text style={styles.total}>{totalKm.toFixed(1)} <Text style={styles.totalUnit}>km</Text></Text>
              <View style={{flexDirection:'row', gap:10, marginTop:12}}>
                <Pressable style={[styles.btn, styles.btnSecondary]} onPress={onClear}><Text style={styles.btnSecondaryText}>Reset Entries</Text></Pressable>
              </View>
            </View>

            <View style={styles.card}>
              <Text style={styles.muted}>Recent Refills</Text>
              {entries.length===0 ? (
                <Text style={styles.muted}>No entries yet. Add your first refill.</Text>
              ):(
                <FlatList data={entries} keyExtractor={(i)=>i.id} ItemSeparatorComponent={()=> <View style={{height:12}}/>}
                  renderItem={({item})=>(
                    <View style={styles.item}>
                      <View>
                        <Text style={styles.itemTitle}>{item.km.toFixed(1)} km</Text>
                        <Text style={styles.itemSub}>₹{item.amount.toFixed(2)} • {new Date(item.at).toLocaleString()}</Text>
                      </View>
                      <Pressable onPress={()=>onDelete(item.id)}><Text style={styles.danger}>Delete</Text></Pressable>
                    </View>
                  )}
                />
              )}
            </View>
          </View>
        )}

        {tab==='add' && (
          <View style={{gap:16, marginTop:16}}>
            <View style={styles.card}>
              <Text style={styles.label}>Amount Paid (₹)</Text>
              <TextInput value={amount} onChangeText={setAmount} placeholder="e.g., 500" placeholderTextColor={C.muted} keyboardType="decimal-pad" style={styles.input}/>
              <View style={{height:12}}/>
              <Text style={styles.label}>Using Settings</Text>
              <View style={{flexDirection:'row', gap:8, flexWrap:'wrap'}}>
                <View style={styles.pill}><Text style={styles.pillText}>Petrol ₹/L: {settings.pricePerLitre || '—'}</Text></View>
                <View style={styles.pill}><Text style={styles.pillText}>Mileage km/L: {settings.mileageKmPerLitre || '—'}</Text></View>
              </View>
              <View style={{marginTop:14}}>
                <Text style={styles.muted}>Calculated</Text>
                <Text style={styles.calcGood}>{computedKm.toFixed(1)} km</Text>
              </View>
              <View style={{marginTop:16}}>
                <Pressable style={styles.btn} onPress={onAdd}><Text style={styles.btnText}>Add to Total</Text></Pressable>
              </View>
            </View>
            <View style={styles.card}><Text style={styles.hint}>Formula: km = (Amount / Petrol Price per Litre) × Bike Mileage (km/L)</Text></View>
          </View>
        )}

        {tab==='settings' && (
          <View style={{gap:16, marginTop:16}}>
            <View style={styles.card}>
              <Text style={styles.label}>Petrol Price (₹/L)</Text>
              <TextInput value={settings.pricePerLitre} onChangeText={(t)=>setSettings(s=>({...s, pricePerLitre:t}))} placeholder="e.g., 110" placeholderTextColor={C.muted} keyboardType="decimal-pad" style={styles.input}/>
              <View style={{height:14}}/>
              <Text style={styles.label}>Bike Mileage (km/L)</Text>
              <TextInput value={settings.mileageKmPerLitre} onChangeText={(t)=>setSettings(s=>({...s, mileageKmPerLitre:t}))} placeholder="e.g., 45" placeholderTextColor={C.muted} keyboardType="decimal-pad" style={styles.input}/>
              <View style={{height:16}}/>
              <Pressable style={styles.btn} onPress={onSave}><Text style={styles.btnText}>Save Settings</Text></Pressable>
            </View>
            <View style={styles.card}><Text style={styles.hint}>Tip: Set these once. Update when petrol price or mileage changes. Then, on Add, enter only the amount paid.</Text></View>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1, backgroundColor:C.bg}, wrap:{flex:1, padding:16},
  title:{fontSize:28, fontWeight:'800', color:C.text, letterSpacing:.2}, subtitle:{fontSize:14, color:C.muted, marginTop:4},
  seg:{flexDirection:'row', backgroundColor:C.card, borderRadius:12, padding:4, borderWidth:1, borderColor:C.border, marginTop:16},
  segBtn:{flex:1, paddingVertical:10, borderRadius:8, alignItems:'center'}, segBtnActive:{backgroundColor:C.accent},
  segText:{color:C.muted, fontWeight:'700'}, segTextActive:{color:'#fff'},
  card:{backgroundColor:C.card, borderRadius:16, padding:16, borderWidth:1, borderColor:C.border},
  label:{color:C.muted, fontSize:13, marginBottom:6}, input:{backgroundColor:'#0F1620', color:C.text, borderWidth:1, borderColor:C.border, borderRadius:12, paddingHorizontal:14, paddingVertical:Platform.OS==='ios'?14:10, fontSize:16},
  total:{color:C.text, fontSize:48, fontWeight:'900'}, totalUnit:{fontSize:18, color:C.muted},
  btn:{backgroundColor:C.accent, borderWidth:1, borderColor:C.accent, paddingVertical:14, borderRadius:12, alignItems:'center'}, btnText:{color:'#fff', fontWeight:'700', fontSize:16},
  btnSecondary:{backgroundColor:'transparent', borderColor:C.border}, btnSecondaryText:{color:C.text, fontWeight:'700', fontSize:16},
  muted:{color:C.muted}, mutedSmall:{color:C.muted, fontSize:13, marginBottom:6},
  item:{backgroundColor:'#0E141C', borderWidth:1, borderColor:C.border, borderRadius:12, padding:12, flexDirection:'row', justifyContent:'space-between', alignItems:'center'},
  itemTitle:{color:C.text, fontWeight:'700'}, itemSub:{color:C.muted, fontSize:12}, danger:{color:C.danger, fontWeight:'700'},
  calcGood:{color:C.good, fontSize:32, fontWeight:'900'},
  pill:{paddingHorizontal:10, paddingVertical:6, backgroundColor:'#0E141C', borderRadius:999, borderWidth:1, borderColor:C.border},
  pillText:{color:C.muted, fontSize:12}, hint:{color:C.muted, fontSize:13}
});
