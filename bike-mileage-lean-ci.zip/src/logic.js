export function computeKilometers(amountPaid, pricePerLitre, kmPerLitre){
  const amt = Number(amountPaid), ppl = Number(pricePerLitre), kmpl = Number(kmPerLitre);
  if(!isFinite(amt)||!isFinite(ppl)||!isFinite(kmpl)||amt<=0||ppl<=0||kmpl<=0) return 0;
  return (amt / ppl) * kmpl; // km = (₹ / ₹/L) * (km/L)
}
export function sumKilometers(entries){ return entries.reduce((s,e)=>s+(Number(e.km)||0),0); }
