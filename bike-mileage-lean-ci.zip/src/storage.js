import AsyncStorage from '@react-native-async-storage/async-storage';
export const STORAGE_KEYS = { settings: 'bm_settings_vlean', entries: 'bm_entries_vlean' };
export async function loadSettings(){
  try{ const raw=await AsyncStorage.getItem(STORAGE_KEYS.settings);
    return raw?JSON.parse(raw):{ pricePerLitre:'', mileageKmPerLitre:'' };
  }catch{ return { pricePerLitre:'', mileageKmPerLitre:'' }; }
}
export async function saveSettings(s){ await AsyncStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(s)); }
export async function loadEntries(){
  try{ const raw=await AsyncStorage.getItem(STORAGE_KEYS.entries); return raw?JSON.parse(raw):[]; }
  catch{ return []; }
}
export async function saveEntries(list){ await AsyncStorage.setItem(STORAGE_KEYS.entries, JSON.stringify(list)); }
